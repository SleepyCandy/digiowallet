package com.digiowallet.DGOWallet.Entitys;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;

public class datetimePOJO {

    private String Username;
    private String start;
    private String ended;


    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getEnded() {
        return ended;
    }

    public void setEnded(String ended) {
        this.ended = ended;
    }
}
