package com.digiowallet.DGOWallet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DgoWalletApplication {

	public static void main(String[] args) {
		SpringApplication.run(DgoWalletApplication.class, args);
	}
}
